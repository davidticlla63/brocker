export default {
    SECRET:'PATRIA'
}